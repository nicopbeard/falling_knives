/*
 * Copyright (c) 1994, 1995, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 * Generic text file handler
 */
package sun.net.www.content.text;

public class Generic extends plain {
    /* nothing to do since Generic is identical to plain! */
}
